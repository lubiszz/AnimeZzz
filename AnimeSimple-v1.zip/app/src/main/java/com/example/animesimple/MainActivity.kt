package com.example.animesimple

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val anime = listOf(
        "Solo Leveling" to "Action • Fantasy",
        "One Piece" to "Adventure • Shounen",
        "Demon Slayer" to "Action • Supernatural",
        "My Hero Academia" to "Action • School"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 16)
            setBackgroundColor(Color.rgb(17,17,17))
        }

        val title = TextView(this).apply {
            text = "Anime Simple"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val search = EditText(this).apply {
            hint = "Cari anime..."
            setSingleLine()
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 60))

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        anime.forEach { (name, genre) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 18, 20, 18)
                setBackgroundColor(Color.rgb(30,30,30))
                val lp = LinearLayout.LayoutParams(-1, 120)
                lp.setMargins(0, 12, 0, 0)
                layoutParams = lp
            }
            val n = TextView(this).apply {
                text = name
                textSize = 20f
                setTextColor(Color.WHITE)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val g = TextView(this).apply {
                text = genre
                textSize = 14f
                setTextColor(Color.LTGRAY)
            }
            card.addView(n)
            card.addView(g)
            card.setOnClickListener { showAnime(name, genre) }
            list.addView(card)
        }

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showAnime(name: String, genre: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(17,17,17))
        }
        val back = Button(this).apply {
            text = "← Kembali"
            setOnClickListener { showHome() }
        }
        root.addView(back)
        val title = TextView(this).apply {
            text = name
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)
        val desc = TextView(this).apply {
            text = "$genre\n\nPilih episode untuk menonton."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 16, 0, 16)
        }
        root.addView(desc)

        for (i in 1..6) {
            val ep = Button(this).apply {
                text = "Episode $i"
                setOnClickListener {
                    Toast.makeText(this@MainActivity,
                        "Tambahkan URL video resmi untuk Episode $i",
                        Toast.LENGTH_SHORT).show()
                }
            }
            root.addView(ep, LinearLayout.LayoutParams(-1, 60))
        }
        setContentView(root)
    }
}
